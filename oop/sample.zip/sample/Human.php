<?php 

class Human 
{
    // プロパティ(属性)
    public $name;

    public function walk()
    {
        echo '歩く';
    }
}